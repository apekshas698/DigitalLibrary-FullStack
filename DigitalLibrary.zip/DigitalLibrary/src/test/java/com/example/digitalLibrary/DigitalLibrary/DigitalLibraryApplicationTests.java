package com.example.digitalLibrary.DigitalLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
